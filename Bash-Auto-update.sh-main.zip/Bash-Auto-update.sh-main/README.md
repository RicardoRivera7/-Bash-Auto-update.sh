# Bash-Auto-update.sh
A small bash script that checks for any dependencies that need to be installed and then installs them if needed
